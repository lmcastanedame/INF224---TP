# INF224 - TP
The aim of this practical work is to create the software outline for a multimedia set-top box allowing you to play videos, films, display photos, etc. This software will be produced in stages, limiting itself to the declaration and implementation of a few typical classes and functionalities which will be completed gradually. 
