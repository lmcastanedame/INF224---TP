// Author: Laura Manuela Castañeda Medina
//
// main.cpp
// Created on 21/10/2018
//

#include <iostream>
#include <string>
#include <vector>
#include <memory> // for std::shared_ptr
#include "MultimediaObject.h"
#include "Photo.h"
#include "Video.h"
#include "Film.h"
#include "Group.h"
#include "Manager.h"

#include "tcpserver.h"

int main() {

    return 0;
}
